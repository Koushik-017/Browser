package com.firebasedandroid.com.browser;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UrlSearch extends AppCompatActivity implements View.OnClickListener {
private Button SearchUrlButton;
private EditText UrlInput;;
private  Button HomeButton;
private WebView SearchWebAddress;
String url;
private ProgressDialog Loadingbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_url_search);

        Loadingbar = new ProgressDialog(this);

        SearchUrlButton = (Button)findViewById(R.id.Search_Url_Button);
        UrlInput=(EditText)findViewById(R.id.Input_Search_url);
        HomeButton=(Button)findViewById(R.id.Home_Button);
        SearchWebAddress=(WebView)findViewById(R.id.Search_Website);



         url = getIntent().getExtras().get("url_adress").toString();
         UrlInput.setText(url);

        WebSettings webSettings = SearchWebAddress.getSettings();
        webSettings.setJavaScriptEnabled(true);
        SearchWebAddress.loadUrl(url);
        SearchWebAddress.setWebViewClient(new WebViewClient());


        Loadingbar.setTitle("Loading....");
        Loadingbar.setMessage("please wait while we are opening your requestd web address.");
        Loadingbar.show();




        SearchUrlButton.setOnClickListener(this);
        HomeButton.setOnClickListener(this);




    }

    @Override
    public void onBackPressed()
    {
        if(SearchWebAddress.canGoBack())
        {
            SearchWebAddress.goBack();
        }
        else
            {
            super.onBackPressed();
        }
    }






    @Override
    public void onClick(View view) {
        if(view== HomeButton)
        {
            finish();
            Intent homePage = new Intent(UrlSearch.this,MainActivity.class);
            startActivity(homePage);
        }
        if (view==SearchUrlButton){
            SearchWebAddress();
        }

    }

    private void SearchWebAddress() {

        Loadingbar.setTitle("Loading");
        Loadingbar.setMessage("please wait while we are opening your requestd web address.");
        Loadingbar.show();



        String Url_Address = UrlInput.getText().toString();

        if (TextUtils.isEmpty(Url_Address))
        {
            Toast empty = Toast.makeText(UrlSearch.this,"Please enter Url or Web Address",Toast.LENGTH_LONG);
            empty.show();
        }
        else {
            String Url_Without_https = Url_Address.replaceAll("https://www.","");
            String https = "https://";
            String www = "www.";
            Intent search = new Intent(UrlSearch.this,UrlSearch.class);
            search.putExtra("url_adress",https+www+Url_Without_https );
            startActivity(search);


            UrlInput.setText("");
            UrlInput.requestFocus();
        }
    }
}

