package com.firebasedandroid.com.browser;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{
private Button SearchButtonHome;
private EditText InputURL;
private Button facebook_btn;
    private Button youtube_btn;
    private Button instagram_btn;
    private Button snapchat_btn;
    private Button google_btn;
    private Button yahoo_btn;
    private ProgressDialog Loadingbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Loadingbar = new ProgressDialog(this);


        SearchButtonHome = (Button)findViewById(R.id.search_button_home);
        InputURL = (EditText)findViewById(R.id.search_url_home);
        facebook_btn = (Button) findViewById(R.id.facebook);
        youtube_btn = (Button) findViewById(R.id.youtube);
        instagram_btn = (Button) findViewById(R.id.instagram);
        snapchat_btn= (Button) findViewById(R.id.snacpchat);
        google_btn = (Button) findViewById(R.id.google);
        yahoo_btn = (Button) findViewById(R.id.yahoo);


        SearchButtonHome.setOnClickListener(this);
        facebook_btn.setOnClickListener(this);
        youtube_btn.setOnClickListener(this);
        instagram_btn.setOnClickListener(this);
        snapchat_btn.setOnClickListener(this);
        google_btn.setOnClickListener(this);
        yahoo_btn.setOnClickListener(this);

    }




    @Override
    public void onClick(View view) {

        if (view == SearchButtonHome){
        OpenWebsite();
    }
      if(view == facebook_btn)  {
          Intent Open_facebook = new Intent(MainActivity.this,UrlSearch.class);
          Open_facebook.putExtra("url_adress","https://facebook.com");
          startActivity(Open_facebook);



      }

        if(view == youtube_btn)  {
            Intent Open_youtube = new Intent(MainActivity.this,UrlSearch.class);
            Open_youtube.putExtra("url_adress","https://youtube.com");
            startActivity(Open_youtube);

        }
        if(view == instagram_btn)  {
            Intent Open_instagram = new Intent(MainActivity.this,UrlSearch.class);
            Open_instagram.putExtra("url_adress","https://instagram.com");
            startActivity(Open_instagram);

        }
        if(view == snapchat_btn)  {
            Intent Open_snapchat = new Intent(MainActivity.this,UrlSearch.class);
            Open_snapchat.putExtra("url_adress","https://snapchat.com");
            startActivity(Open_snapchat);

        }
        if(view == google_btn)  {
            Intent Open_google = new Intent(MainActivity.this,UrlSearch.class);
            Open_google.putExtra("url_adress","https://google.com");
            startActivity(Open_google);

        }
        if(view == yahoo_btn)  {
            Intent Open_yahoo = new Intent(MainActivity.this,UrlSearch.class);
            Open_yahoo.putExtra("url_adress","https://yahoo.com");
            startActivity(Open_yahoo);

        }


    }

    private void OpenWebsite()
    {
        Loadingbar.setTitle("Loading...");
        Loadingbar.setMessage("please wait while we are opening your requestd web address..");
        Loadingbar.show();

        String Url_Address = InputURL.getText().toString();

        if (TextUtils.isEmpty(Url_Address))
        {
            Toast empty = Toast.makeText(MainActivity.this,"Please enter Url or Web Address",Toast.LENGTH_LONG);
            empty.show();
        }
        else {
            String Url_Without_https = Url_Address.replaceAll("https://www.","");
            String https = "https://";
            String www = "www.";
            Intent search = new Intent(MainActivity.this,UrlSearch.class);
             search.putExtra("url_adress",https+www+Url_Without_https );
             startActivity(search);

            InputURL.setText("");
            InputURL.requestFocus();

        }
    }
}